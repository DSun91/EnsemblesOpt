# Example Package

A package for speeding up the process of finding best base learners for ensemble models trough Bayesian Optimization.